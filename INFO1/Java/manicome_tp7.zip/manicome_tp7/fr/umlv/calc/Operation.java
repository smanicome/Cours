package fr.umlv.calc;

public abstract class Operation {
    public void display() {
        System.out.println(toString());
    }
}
