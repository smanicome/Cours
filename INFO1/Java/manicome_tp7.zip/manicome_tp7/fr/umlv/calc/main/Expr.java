package fr.umlv.calc.main;

import fr.umlv.calc.OpOrValue;
import fr.umlv.calc.OpOrValueCopy;

import java.util.Iterator;
import java.util.Objects;

public class Expr {
    private final Value left;
    private final Value right;

    public Expr(Value left, Value right) {
        this.left = Objects.requireNonNull(left);
        this.right = Objects.requireNonNull(right);
    }

    @Override
    public String toString() {
        return "Expr{" + "left=" + left + ", right=" + right + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Expr expr = (Expr) o;
        return left.equals(expr.left) && right.equals(expr.right);
    }

    public int eval() {
        return 0;
    }

    public void display(OpOrValueCopy expression) {

    }

    public OpOrValueCopy parse(Iterator<String> iterator) {
        return null;
    }
}
