package fr.umlv.calc.main;

import fr.umlv.calc.OpOrValueCopy;

import java.util.Iterator;

public class Value {
    private final int value;

    public Value(int value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "Value{" + "value=" + value +'}';
    }
}
