#ifndef DOTOINDEX_H
#define DOTOINDEX_H

int getTo(char* c, unsigned int index, FILE* fd);
int readUntil(char* c, FILE* fd);
unsigned int countIndex(char* c, FILE* fd);

#endif