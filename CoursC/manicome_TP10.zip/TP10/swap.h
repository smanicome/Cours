#ifndef SWAP_H
#define SWAP_H
#include <stdlib.h>

void swap_mem(void *z1, void *z2, size_t size);

#endif
