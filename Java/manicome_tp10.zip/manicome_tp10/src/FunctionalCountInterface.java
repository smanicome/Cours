import java.util.List;

public interface FunctionalCountInterface {
    public long compute();
}
