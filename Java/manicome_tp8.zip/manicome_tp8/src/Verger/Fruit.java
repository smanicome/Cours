package Verger;

import java.util.Objects;

public interface Fruit {
    public double getPrice();
}
