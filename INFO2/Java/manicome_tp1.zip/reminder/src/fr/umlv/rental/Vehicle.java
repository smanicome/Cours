package fr.umlv.rental;

public interface Vehicle {
	public int year();
	public long insuranceCostAt(int value);
}
