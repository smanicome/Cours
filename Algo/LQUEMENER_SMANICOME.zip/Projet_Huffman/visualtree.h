#ifndef __VISUAL_TREE_H__
#define __VISUAL_TREE_H__

#include "node.h"

void write_tree(node *t);

#endif