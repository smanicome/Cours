#ifndef __ENCODE_H__
#define __ENCODE_H__

#include <stdio.h>

void encode(FILE *fdin, FILE *fdout, char **code_table);

#endif