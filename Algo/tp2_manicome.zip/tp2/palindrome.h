#ifndef PALINDROME_H_
#define PALINDROME_H_

int palindrome_rec(char const *word, int lo, int hi);
int palindrome(char const *word);

#endif