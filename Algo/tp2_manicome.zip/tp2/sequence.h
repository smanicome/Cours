#ifndef SEQUENCE_H_
#define SEQUENCE_H_

void increasing_sequence_rec(int n);
void decreasing_sequence_rec(int n);
int longest_incr_iter(int t[], int lo, int hi);
int first_incr(int t[], int lo, int hi);
int longest_incr_rec(int t[], int lo, int hi);

#endif