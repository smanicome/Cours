#ifndef SUM_H_
#define SUM_H_

int sum_digits_iter(int n);
int sum_digits_rec(int n);
int digit_sum_digits_iter(int n);
int digit_sum_digits_rec(int n);

#endif