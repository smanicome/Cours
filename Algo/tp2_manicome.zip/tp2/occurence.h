#ifndef OCCURENCE_H_
#define OCCURENCE_H_

int count(int t[], int lo, int hi, int elt);
int max_count(int t[], int lo, int hi);

#endif